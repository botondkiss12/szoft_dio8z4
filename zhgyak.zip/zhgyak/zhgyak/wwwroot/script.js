﻿fetch("api/films").then(v => v.json()).then(o => {
    let tbody = document.getElementById("tbfilms");
    console.log("GET:", o)
    o.forEach(e => {
        let tr = document.createElement("tr");
        tr.innerHTML = `
        <td>${e.filmId}</td>
        <td>${e.title}</td>
        <td>${e.releaseYear}</td>
        <td>${e.genre}</td>
        <td>${e.isAvailable}</td>
        `;
        tbody.appendChild(tr);
    });
});

document.getElementById("button2").addEventListener("click", () => {
    let data = {
        title: document.getElementById("title").value,
        releaseYear: parseInt(document.getElementById("release").value),
        genre: document.getElementById("genre").value,
        isAvailable: document.getElementById("avalible").value === "true"
    };

    fetch("api/films", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    }).then(() => {
        window.location.reload();
    });

});